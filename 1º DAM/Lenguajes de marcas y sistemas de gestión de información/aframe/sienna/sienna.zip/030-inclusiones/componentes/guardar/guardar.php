<?php
	/*
		Archivo que gestiona el componente del botón de guardado
	*/
?>
<button id="guardar">Guardar</button>
    
<style>
	<?php include "guardar.css";?>
</style>
<script>
	<?php include "guardar.js";?>
</script>
